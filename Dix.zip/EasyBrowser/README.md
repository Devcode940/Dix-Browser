# Dix Browser

A modern, lightweight Android browser built with WebView. Fully modernized with a clean architecture, English UI, and enhanced features.

![Demo Screenshots](img/Screenshot_1.jpg) ![Demo Screenshots](img/Screenshot_2.jpg) ![Demo Screenshots](img/Screenshot_3.jpg)

---

## ✨ Features

### Phase 1 — Core Foundation (Complete)
- **Modern Address Bar** with smart URL/search detection
- **Multi-tab support** (foreground/background creation, switching, LRU caching)
- **Download Manager** with progress tracking and file opening
- **Settings Screen** (search engine, JavaScript, cookies, dark mode)
- **Enhanced History** with search and deletion
- **Bookmarks** infrastructure
- Basic navigation (back, forward, refresh, home)

### Phase 2 — Privacy & Theming (Foundation Complete)
- **Incognito / Private Mode** (separate tabs with no history or storage)
- **Dark Mode** with system theme support
- **Basic Ad Blocking**

### Phase 3 — Advanced Features (In Progress)
- **Desktop Mode** (switch to desktop User-Agent)
- **Full Screen** browsing
- **Page Translation** (Free auto translation)
- **Resource Sniffer** (download images/videos from page)
- **Picture-in-Picture Video**
- **Customizable Toolbars**
- **Arena.ai Summarizer** — In-app page & text summarization using Arena.ai
- **Auto Session Restoration**
- **Password Saving** & Form Autofill
- **Page Saving** for offline reading

### Security & Quality Improvements (Ongoing)
- Centralized **WebView Security Config** (JavaScript disabled by default)
- **Secure SSL Certificate Validation**
- **Encrypted Password Storage** using `EncryptedSharedPreferences`
- **Improved WebView Lifecycle Management** (pause/resume/destroy)
- **Proper Error Handling** in WebView
- **ProGuard/R8 Rules** for release builds

### Technical Highlights
- Built with modern Android development practices
- Kotlin + ViewBinding + MVVM architecture
- Target SDK 35
- Material Design components

---

## 🚀 Getting Started

### Requirements
- Android Studio Hedgehog or newer
- JDK 17+
- Android SDK 35

### Build Instructions

1. Clone the repository:
   ```bash
   git clone https://github.com/Devcode940/DixBrowser.git
   cd DixBrowser
   ```

2. Open the project in Android Studio.

3. Sync Gradle and build the project.

4. Run on an emulator or physical device.

---

## 📁 Project Structure

```
app/src/main/java/ricky/easybrowser/
├── ui/
│   ├── address/          # Address bar + search
│   ├── browser/          # Main browser logic
│   ├── download/         # Download manager
│   ├── history/          # Browsing history
│   ├── incognito/        # Private mode
│   ├── settings/         # Settings screen
│   ├── theme/            # Dark mode
│   └── adblock/          # Ad blocker
├── web/                  # WebView implementations
└── contract/             # Interfaces
```

---

## 🛠️ Roadmap

### Completed
- ✅ Phase 1: Core browser functionality
- ✅ Phase 2: Privacy features (Incognito + Dark Mode)

### Planned
- Full Kotlin migration
- Hilt dependency injection
- Reader Mode
- Advanced ad blocking
- Gesture navigation
- Tab groups

See [FEATURE_ROADMAP.md](FEATURE_ROADMAP.md) and [PHASE2_IMPLEMENTATION_PLAN.md](PHASE2_IMPLEMENTATION_PLAN.md) for details.

---

## 🤝 Contributing

Contributions are welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Submit a pull request

---

## 📄 License

This project is open source and available under the MIT License.

---

## 📸 Screenshots

| Main Browser | Tabs | Settings |
|--------------|------|----------|
| ![Screenshot 1](img/Screenshot_1.jpg) | ![Screenshot 2](img/Screenshot_2.jpg) | ![Screenshot 3](img/Screenshot_3.jpg) |

---

**Dix Browser** — A simple yet powerful Android browser experience.

*Last updated: 2026-07-22*