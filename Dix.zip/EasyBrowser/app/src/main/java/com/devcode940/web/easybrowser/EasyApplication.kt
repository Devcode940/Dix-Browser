package com.devcode940.web.easybrowser

import android.app.Application
import dagger.hilt.android.HiltAndroidApp
import com.devcode940.web.easybrowser.web.WebViewSecurityConfig

/**
 * Application class with Hilt support
 */
@HiltAndroidApp
class EasyApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        // Security: Disable remote WebView debugging in production
        // Only enable during development if needed
        WebViewSecurityConfig.disableRemoteDebugging()
    }
}