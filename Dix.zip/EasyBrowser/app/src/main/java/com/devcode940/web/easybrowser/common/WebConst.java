package com.devcode940.web.common;

public class WebConst {
    public static class Header {
        public static final String CONTENT_TYPE = "content-type";
    }
}
