package com.devcode940.web.contract;

import java.util.List;

import com.devcode940.web.entity.dao.WebSite;

public interface IFrontPage {

    interface View {
        void showWebSite(List<WebSite> webSiteList);
    }

    interface Presenter {
        void getWebSite();
    }
}
