package com.devcode940.web.contract;

import java.util.List;

import com.devcode940.web.entity.dao.History;

public interface IHistory {

    interface View {
        void showHistory(List<History> result);
        void showEmptyResult();
    }

    interface Presenter {
        void getHistory(int pageNo, int pageSize);
        void onDestroy();
    }
}
