package com.devcode940.web.contract;

import android.graphics.Bitmap;

import com.devcode940.web.entity.bo.TabInfo;

public interface ITab {
    TabInfo provideTabInfo();

    boolean onBackPressed();

    void goForward();

    void gotoHomePage();

    void loadUrl(String url);

    Bitmap getTabPreview();
}
