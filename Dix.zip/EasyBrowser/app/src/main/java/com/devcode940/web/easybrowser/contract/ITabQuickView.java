package com.devcode940.web.contract;

import java.util.List;

import com.devcode940.web.entity.bo.TabInfo;

public interface ITabQuickView {

    interface Subject {
        void attach(Observer observer);

        void detach();

        List<TabInfo> provideInfoList();

        void updateTabInfo(TabInfo info);
    }

    interface Observer {
        void updateQuickView();
    }
}
