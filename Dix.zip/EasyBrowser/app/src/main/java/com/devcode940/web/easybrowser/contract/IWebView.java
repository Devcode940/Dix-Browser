package com.devcode940.web.contract;

import android.graphics.Bitmap;

import com.devcode940.web.entity.bo.ClickInfo;
import com.devcode940.web.entity.bo.TabInfo;

public interface IWebView {

    void setOnWebInteractListener(OnWebInteractListener listener);

    OnWebInteractListener getOnWebInteractListener();

    void loadUrl(String url);

    void goBack();

    boolean canGoBack();

    void goForward();

    boolean canGoForward();

    void releaseSession();

    void onResume();

    void onPause();

    void onDestroy();

    Bitmap capturePreview();


    interface OnWebInteractListener {
        void onPageTitleChange(TabInfo tabInfo);

        void onLongClick(ClickInfo clickInfo);
    }
}
