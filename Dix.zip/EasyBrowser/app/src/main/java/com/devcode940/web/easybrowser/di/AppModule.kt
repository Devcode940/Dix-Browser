package com.devcode940.web.easybrowser.di

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import com.devcode940.web.easybrowser.data.TabRepository
import com.devcode940.web.easybrowser.domain.LoadUrlUseCase

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    fun provideTabRepository(): TabRepository = TabRepository()

    @Provides
    fun provideLoadUrlUseCase(): LoadUrlUseCase = LoadUrlUseCase()
}