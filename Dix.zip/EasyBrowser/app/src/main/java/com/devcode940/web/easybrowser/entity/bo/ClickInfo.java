package com.devcode940.web.entity.bo;

public class ClickInfo {

    public String url;
    public int type;
}
