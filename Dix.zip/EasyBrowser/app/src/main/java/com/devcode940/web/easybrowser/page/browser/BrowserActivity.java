package com.devcode940.web.page.browser;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.UiThread;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import com.devcode940.web.EasyApplication;
import com.devcode940.web.R;
import com.devcode940.web.common.BrowserConst;
import com.devcode940.web.common.Const;
import com.devcode940.web.common.TabConst;
import com.devcode940.web.contract.IBrowser;
import com.devcode940.web.entity.bo.ClickInfo;
import com.devcode940.web.entity.bo.TabInfo;
import com.devcode940.web.entity.dao.AppDatabase;
import com.devcode940.web.entity.dao.History;
import com.devcode940.web.page.address.AddressDialog;
import com.devcode940.web.page.history.HistoryActivity;
import com.devcode940.web.page.setting.SettingDialogKt;
import com.devcode940.web.contract.ITab;
import com.devcode940.web.page.tabpreview.TabDialogKt;
import com.devcode940.web.ui.address.AddressBarManager;
import com.devcode940.web.ui.address.AddressBarView;
import com.devcode940.web.ui.theme.ThemeManager;
import com.devcode940.web.ui.desktop.DesktopModeManager;
import com.devcode940.web.ui.fullscreen.FullscreenManager;
import com.devcode940.web.ui.translate.TranslateManager;
import com.devcode940.web.ui.pip.PictureInPictureManager;
import com.devcode940.web.utils.FragmentBackHandleHelper;
import com.devcode940.web.utils.TabHelper;
import com.devcode940.web.contract.IWebView;

public class BrowserActivity extends AppCompatActivity implements IWebView.OnWebInteractListener,
        IBrowser {

    private static final String TAG = "BrowserActivity";

    private static final String SETTING_DIALOG_TAG = "setting_dialog";
    private static final String TAB_DIALOG_TAG = "tab_dialog";
    private static final String ADDRESS_DIALOG_TAG = "address_dialog";

    FrameLayout webContentFrame;

    // Modern Address Bar
    private AddressBarView addressBarView;

    // Download Manager
    private com.devcode940.web.ui.download.BrowserDownloadManager downloadManager;

    // Phase 3 Managers
    private DesktopModeManager desktopModeManager;
    private FullscreenManager fullscreenManager;
    private TranslateManager translateManager;
    private PictureInPictureManager pipManager;

    IBrowser.INavController navController;
    IBrowser.IHistoryController historyController;
    IBrowser.ITabController tabController;
    IBrowser.IBookmarkController bookmarkController;
    IBrowser.IDownloadController downloadController;
    IBrowser.IComponent stubComponent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browser_modern);

        getTabController();

        webContentFrame = findViewById(R.id.web_content_frame);

        // Initialize modern address bar
        addressBarView = findViewById(R.id.address_bar);
        setupAddressBar();
        setupNavigationButtons();

        // Initialize Download Manager
        downloadManager = new com.devcode940.web.ui.download.BrowserDownloadManager(this);

        // Initialize Phase 3 Managers
        desktopModeManager = new DesktopModeManager();
        fullscreenManager = new FullscreenManager(this);
        translateManager = new TranslateManager(this);
        pipManager = new PictureInPictureManager(this);

        // Apply saved theme preference
        applyThemeFromPreferences();

        // Enable secure password saving
        com.devcode940.web.easybrowser.ui.password.PasswordManager.enablePasswordSaving(this);

        // Restore previous session (Auto Restoration)
        restorePreviousSession();

        if (savedInstanceState == null) {
            TabInfo tabInfo = TabInfo.create(
                    System.currentTimeMillis() + "",
                    getString(R.string.new_tab_welcome));
            getTabController().onTabCreate(tabInfo, false);
        } else {
            Fragment prevDialog = getSupportFragmentManager().findFragmentByTag(TAB_DIALOG_TAG);
            if (prevDialog instanceof TabDialogKt) {
                ((TabDialogKt) prevDialog).setTabViewSubject(getTabController());
                ((TabDialogKt) prevDialog).dismiss();
            }
        }
    }

    private void setupAddressBar() {
        if (addressBarView == null) return;

        addressBarView.setOnUrlSubmitListener(url -> {
            // Load URL in current tab
            getTabController().onTabLoadUrl(url);
            addressBarView.setUrl(url);
        });

        addressBarView.setOnClearListener(() -> {
            // Optional: clear current tab or show home
        });

        // Default search engine
        addressBarView.setSearchEngine(AddressBarManager.SearchEngine.GOOGLE);
    }

    private void setupNavigationButtons() {
        ImageButton btnBack = findViewById(R.id.btn_back);
        ImageButton btnForward = findViewById(R.id.btn_forward);
        ImageButton btnRefresh = findViewById(R.id.btn_refresh);
        ImageButton btnMenu = findViewById(R.id.btn_menu);

        btnBack.setOnClickListener(v -> getTabController().onTabGoBack());
        btnForward.setOnClickListener(v -> getTabController().onTabGoForward());
        btnRefresh.setOnClickListener(v -> getTabController().onTabRefresh());

        btnMenu.setOnClickListener(v -> showSettingDialog());
    }

    // Download integration
    public void onDownloadStart(String url, String userAgent, String contentDisposition,
                                String mimeType, long contentLength) {
        long downloadId = downloadManager.startDownload(url, userAgent, contentDisposition, mimeType, contentLength);
        Toast.makeText(this, getString(R.string.download_started), Toast.LENGTH_SHORT).show();
    }

    // ==================== DARK MODE ====================
    private void applyThemeFromPreferences() {
        // Default to system theme or read from SharedPreferences
        boolean darkModeEnabled = getSharedPreferences("settings", MODE_PRIVATE)
                .getBoolean("dark_mode", false);

        if (darkModeEnabled) {
            ThemeManager.applyDarkMode(true);
        } else {
            ThemeManager.applySystemDefault();
        }
    }

    public void toggleDarkMode(boolean enable) {
        ThemeManager.applyDarkMode(enable);
        getSharedPreferences("settings", MODE_PRIVATE)
                .edit()
                .putBoolean("dark_mode", enable)
                .apply();
    }

    // ==================== PHASE 3 FEATURES ====================

    public void toggleDesktopMode(boolean enable) {
        desktopModeManager.setDesktopMode(enable);
        // Reload current page with new User-Agent
        getTabController().onTabRefresh();
    }

    public void toggleFullScreen() {
        fullscreenManager.toggleFullscreen();
    }

    public void translateCurrentPage() {
        String currentUrl = addressBarView != null ? addressBarView.getCurrentUrl() : null;
        if (currentUrl != null) {
            translateManager.translatePage(currentUrl);
        }
    }

    public void enterPictureInPicture() {
        // Use enhanced PiP with Media Controller
        pipManager.enterPictureInPictureMode();
    }

    /**
     * Play video in PiP mode with full media controls
     */
    public void playVideoInPiP(android.net.Uri videoUri) {
        // This would typically be called when a video is detected
        // For now, we show a toast
        Toast.makeText(this, "Starting PiP Video Player...", Toast.LENGTH_SHORT).show();
        // In real implementation, pass the VideoView from WebView or a dedicated player
    }

    public void openResourceSniffer() {
        // Collect resources from current WebView and show dialog
        com.devcode940.web.ui.sniffer.ResourceSnifferDialog dialog =
                com.devcode940.web.ui.sniffer.ResourceSnifferDialog.newInstance();
        dialog.show(getSupportFragmentManager(), "resource_sniffer");
    }

    // ==================== ARENA.AI SUMMARIZER ====================
    public void openArenaSummarizer() {
        String currentUrl = null;
        if (addressBarView != null) {
            currentUrl = addressBarView.getCurrentUrl();
        }

        // Open the advanced Summarizer Fragment
        com.devcode940.web.easybrowser.ui.summarizer.SummarizerFragment fragment =
                com.devcode940.web.easybrowser.ui.summarizer.SummarizerFragment.newInstance(currentUrl);

        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.web_content_frame, fragment)
                .addToBackStack("summarizer")
                .commit();
    }

    // ==================== SAVE PAGE FOR OFFLINE ====================
    public void saveCurrentPageForOffline() {
        // Get the active WebView from the current tab (simplified)
        // In a real implementation, we would get it from TabCacheManager
        Toast.makeText(this, "Saving page for offline viewing...", Toast.LENGTH_SHORT).show();

        // Example: Save using OfflinePageManager
        // com.devcode940.web.easybrowser.ui.offline.OfflinePageManager.saveCurrentPage(webView, this) { path ->
        //     Toast.makeText(this, "Page saved: $path", Toast.LENGTH_LONG).show()
        // };
    }

    // ... rest of the original code remains unchanged ...

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        if (savedInstanceState == null) {
            return;
        }
        ArrayList<TabInfo> restoreList = savedInstanceState.getParcelableArrayList("tablist");
        if (restoreList == null) {
            return;
        }

        getTabController().provideInfoList().addAll(restoreList);
        List<Fragment> restoredFragmentList = getSupportFragmentManager().getFragments();
        if (restoredFragmentList.size() > 0) {
            for (Fragment target : restoredFragmentList) {
                if (target instanceof ITab && target.getArguments() != null) {
                    TabInfo info = TabInfo.create(
                            target.getArguments().getString(TabConst.ARG_TAG),
                            target.getArguments().getString(TabConst.ARG_TITLE));
                    getTabController().onRestoreTabCache(info, target);
                }
            }
        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        ArrayList<TabInfo> storeList = new ArrayList<>();
        storeList.addAll(getTabController().provideInfoList());
        outState.putParcelableArrayList("tablist", storeList);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        // Save current session before closing
        saveCurrentSession();

        if (tabController != null) {
            tabController.onCloseAllTabs();
            tabController.detach();
            tabController.onDestroy();
            tabController = null;
        }
    }

    // ==================== SESSION MANAGEMENT ====================
    private void saveCurrentSession() {
        // In a real implementation, collect all open tabs and save them
        // For now, we just show a placeholder
        // List<SavedTab> tabs = ...;
        // SessionManager.saveTabs(this, tabs);
    }

    private void restorePreviousSession() {
        val savedTabs = com.devcode940.web.easybrowser.ui.session.SessionManager.getSavedTabs(this);
        if (savedTabs.isNotEmpty()) {
            Toast.makeText(this, "Restoring ${savedTabs.size} tabs...", Toast.LENGTH_SHORT).show();
            // TODO: Actually create tabs from savedTabs
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Pause all background tabs for better performance
        com.devcode940.web.easybrowser.web.BackgroundTabManager.pauseAll();
    }

    @Override
    public void onPageTitleChange(TabInfo tabInfo) {
        getTabController().updateTabInfo(tabInfo);
        if (addressBarView != null && tabInfo.url != null) {
            addressBarView.setUrl(tabInfo.url);
        }
    }

    @Override
    public void onLongClick(ClickInfo clickInfo) {
        if (clickInfo == null) {
            return;
        }

        switch (clickInfo.type) {
            case WebView.HitTestResult.IMAGE_TYPE:
                showImageActionDialog(clickInfo);
                break;
            case WebView.HitTestResult.SRC_ANCHOR_TYPE:
            case WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE:
                showUrlActionDialog(clickInfo);
                break;
            default:
                break;
        }
    }

    @Override
    public void onBackPressed() {
        if (FragmentBackHandleHelper.isFragmentBackHandled(getSupportFragmentManager())) {
            return;
        }

        super.onBackPressed();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == Const.RequestCode.SHOW_HISTORY) {
            showHistoryResult(resultCode, data);
        }
    }

    private void showHistoryResult(int resultCode, Intent data) {
        if (resultCode != Activity.RESULT_OK || data == null) {
            return;
        }
        TabInfo info = data.getParcelableExtra(Const.Key.TAB_INFO);
        if (info == null) {
            return;
        }

        getTabController().onTabCreate(info, false);
    }

    private void showTabDialog() {
        Fragment prev = getSupportFragmentManager().findFragmentByTag(TAB_DIALOG_TAG);
        if (prev != null) {
            ((TabDialogKt) prev).dismiss();
            return;
        }

        TabDialogKt tabDialog = new TabDialogKt();
        tabDialog.setCancelable(false);

        tabDialog.setTabViewSubject(getTabController());
        tabDialog.show(getSupportFragmentManager(), TAB_DIALOG_TAG);
    }

    private void showSettingDialog() {
        Fragment prev = getSupportFragmentManager().findFragmentByTag(SETTING_DIALOG_TAG);
        if (prev != null) {
            ((SettingDialogKt) prev).dismiss();
            return;
        }

        SettingDialogKt settingDialog = new SettingDialogKt();
        settingDialog.setCancelable(false);

        settingDialog.show(getSupportFragmentManager(), SETTING_DIALOG_TAG);
    }

    // ==================== INCOGNITO TAB ====================
    public void showIncognitoTab() {
        // Create a new incognito tab
        TabInfo incognitoTab = TabInfo.create(
                "incognito_" + System.currentTimeMillis(),
                "Incognito Tab"
        );
        getTabController().onTabCreate(incognitoTab, false);

        // TODO: In future, load IncognitoTabFragment instead of normal WebView
        Toast.makeText(this, "Incognito tab opened", Toast.LENGTH_SHORT).show();
    }

    private void showAddressDialog(String currentUrl) {
        Fragment prev = getSupportFragmentManager().findFragmentByTag(ADDRESS_DIALOG_TAG);
        if (prev != null) {
            ((AddressDialog) prev).dismiss();
            return;
        }

        AddressDialog addressDialog = new AddressDialog();
        addressDialog.setCurrentUrl(currentUrl);
        addressDialog.show(getSupportFragmentManager(), ADDRESS_DIALOG_TAG);
    }

    private void showImageActionDialog(@NonNull final ClickInfo clickInfo) {
        AlertDialog.Builder imageDialogbuilder = new AlertDialog.Builder(this);
        imageDialogbuilder.setItems(R.array.image_actions, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (which == TabConst.TAB_OPEN_ACTION_BACKSTAGE) {
                    TabHelper.createTab(BrowserActivity.this,
                            R.string.new_tab_welcome,
                            clickInfo.url,
                            true);
                } else if (which == TabConst.TAB_OPEN_ACTION_FRONTSTAGE) {
                    TabHelper.createTab(BrowserActivity.this,
                            R.string.new_tab_welcome,
                            clickInfo.url,
                            false);
                }
            }
        });
        imageDialogbuilder.show();
    }

    private void showUrlActionDialog(@NonNull final ClickInfo clickInfo) {
        AlertDialog.Builder urlDialogbuilder = new AlertDialog.Builder(this);
        urlDialogbuilder.setItems(R.array.url_actions, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (which == TabConst.TAB_OPEN_ACTION_BACKSTAGE) {
                    TabHelper.createTab(BrowserActivity.this,
                            R.string.new_tab_welcome,
                            clickInfo.url,
                            true);
                } else if (which == TabConst.TAB_OPEN_ACTION_FRONTSTAGE) {
                    TabHelper.createTab(BrowserActivity.this,
                            R.string.new_tab_welcome,
                            clickInfo.url,
                            false);
                }
            }
        });
        urlDialogbuilder.show();
    }

    @UiThread
    @NonNull
    @Override
    public IComponent provideBrowserComponent(String componentName) {
        synchronized (this) {
            if (TextUtils.isEmpty(componentName)) {
                return getStubComponent();
            }

            switch (componentName) {
                case BrowserConst.BOOKMARK_COMPONENT:
                    return getBookmarkController();
                case BrowserConst.DOWNLOAD_COMPONENT:
                    return getDownloadController();
                case BrowserConst.HISTORY_COMPONENT:
                    return getHistoryController();
                case BrowserConst.NAVIGATION_COMPONENT:
                    return getNavController();
                case BrowserConst.TAB_COMPONENT:
                    return getTabController();
                default:
                    return getStubComponent();
            }
        }
    }

    private IBrowser.IComponent getStubComponent() {
        if (stubComponent == null) {
            stubComponent = new StubBrowserComponent();
        }
        return stubComponent;
    }

    private IBrowser.IBookmarkController getBookmarkController() {
        if (bookmarkController == null) {
            bookmarkController = new StubBookmarkController();
        }
        return bookmarkController;
    }

    private IBrowser.IDownloadController getDownloadController() {
        if (downloadController == null) {
            downloadController = new StubDownloadController();
        }
        return downloadController;
    }

    private IBrowser.IHistoryController getHistoryController() {
        if (historyController == null) {
            historyController = new EasyHistoryController();
        }
        return historyController;
    }

    private IBrowser.INavController getNavController() {
        if (navController == null) {
            navController = new EasyNavController();
        }
        return navController;
    }

    private IBrowser.ITabController getTabController() {
        if (tabController == null) {
            tabController = new TabCacheManager(this, getSupportFragmentManager(), 3, R.id.web_content_frame);
        }
        return tabController;
    }

    class EasyNavController implements IBrowser.INavController {
        @Override
        public void goBack() {
            onBackPressed();
        }

        @Override
        public void goForward() {
            getTabController().onTabGoForward();
        }

        @Override
        public void goHome() {
            getTabController().onTabGoHome();
        }

        @Override
        public void showTabs() {
            showTabDialog();
        }

        @Override
        public void showAddress(String currentUrl) {
            showAddressDialog(currentUrl);
        }

        @Override
        public void showSetting() {
            showSettingDialog();
        }

        @Override
        public void showHistory() {
            Intent intent = new Intent();
            intent.setClass(BrowserActivity.this, HistoryActivity.class);
            startActivityForResult(intent, Const.RequestCode.SHOW_HISTORY);
        }
    }

    class EasyHistoryController implements IBrowser.IHistoryController {
        @Override
        public void addHistory(final History entity) {
            Disposable dps = Observable.create(new ObservableOnSubscribe<Long>() {

                @Override
                public void subscribe(ObservableEmitter<Long> emitter) throws Exception {
                    final EasyApplication application = (EasyApplication) getApplicationContext();
                    AppDatabase db = application.getAppDatabase();
                    long rowId = db.historyDao().insertHistory(entity);
                    Log.i(TAG, "inserted id    is : " + rowId);
                    Log.i(TAG, "inserted title is : " + entity.title);
                    Log.i(TAG, "inserted url   is : " + entity.url);
                    emitter.onNext(rowId);
                }
            }).observeOn(AndroidSchedulers.mainThread())
                    .subscribeOn(Schedulers.io())
                    .subscribe();
        }
    }

    static class StubDownloadController implements IBrowser.IDownloadController {
    }

    static class StubBookmarkController implements IBrowser.IBookmarkController {
    }

    static class StubBrowserComponent implements IBrowser.IComponent {
    }
}