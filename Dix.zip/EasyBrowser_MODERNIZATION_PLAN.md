# EasyBrowser Modernization Plan

**Date**: 2026-07-22  
**Current State**: Legacy Android project (SDK 28, Gradle 7.0.4, Kotlin 1.6)  
**Target State**: Modern Android 2025+ project (SDK 35, AGP 8.5+, Kotlin 2.0+, Jetpack)

---

## 1. Executive Summary

This plan outlines a step-by-step modernization of **EasyBrowser** to bring it up to current Android development standards while preserving its core multi-tab WebView architecture.

### Goals
- Update build system and dependencies
- Adopt modern Android architecture (MVVM + Jetpack)
- Improve maintainability and scalability
- Prepare for future feature development (Phases 1–4 of the roadmap)
- Enable Kotlin-first development

---

## 2. Current Problems

| Area | Issue | Impact |
|------|-------|--------|
| **Build** | Gradle 7.0.4 + AGP 7.0.4 | Incompatible with modern plugins |
| **SDK** | `compileSdk 28`, `targetSdk 28` | Security & Play Store issues |
| **Language** | Heavy Java + deprecated `kotlin-android-extensions` | Hard to maintain |
| **Architecture** | No ViewModel, no DI, mixed presenters | Poor testability |
| **Dependencies** | Outdated Room, RxJava2, Material 1.3 | Missing modern APIs |
| **Package** | `ricky.easybrowser` | Legacy naming |
| **CI** | Broken Maven-based workflow | No automated builds |

---

## 3. Recommended Modern Stack

| Component | Current | Recommended | Reason |
|-----------|---------|-------------|--------|
| **AGP** | 7.0.4 | 8.5.2+ | Latest stable |
| **Gradle** | 7.5 | 8.8+ | Required by AGP 8+ |
| **Kotlin** | 1.6.10 | 2.0.20 | Latest stable + better performance |
| **compileSdk** | 28 | **35** | Android 15 |
| **targetSdk** | 28 | **35** | Modern requirements |
| **minSdk** | 23 | **24** | Balance (or 26 if preferred) |
| **Jetpack** | Partial | Full (ViewModel, Navigation, Room 2.6+, DataStore) | Modern best practices |
| **DI** | None | **Hilt** (or Koin) | Recommended |
| **UI** | XML + old Material | **Material 3** + optional Compose | Future-proof |
| **Async** | RxJava2 | **Kotlin Coroutines + Flow** | Official recommendation |
| **Navigation** | Manual | **Navigation Component** | Best practice |
| **Database** | Room 2.2.6 + GreenDAO | **Room 2.6.1** | Modern Room |

---

## 4. Proposed New Project Structure

We recommend a **feature-based modular structure** (scalable for future growth).

```
EasyBrowser/
├── app/
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/com/easybrowser/
│   │   │   │   ├── core/                  # Shared utilities, constants, base classes
│   │   │   │   ├── data/                  # Repositories, DAOs, models
│   │   │   │   │   ├── local/
│   │   │   │   │   ├── remote/ (future)
│   │   │   │   ├── repository/
│   │   │   │   ├── model/
│   │   │   │   └── dao/
│   │   │   │   ├── di/                    # Hilt modules
│   │   │   │   ├── ui/
│   │   │   │   │   ├── browser/           # Main browser activity + fragments
│   │   │   │   │   │   ├── tab/
│   │   │   │   │   │   ├── webview/
│   │   │   │   │   ├── history/
│   │   │   │   │   ├── bookmarks/
│   │   │   │   │   ├── settings/
│   │   │   │   │   └── common/
│   │   │   │   ├── utils/
│   │   │   │   └── MainActivity.kt
│   │   │   └── res/
│   │   └── test/
│   └── build.gradle.kts
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
└── .github/workflows/
```

### Alternative (Simpler for now)
Keep a **flat structure** but modernize packages:

```
com.easybrowser/
├── browser/
├── common/
├── data/
├── ui/
│   ├── address/
│   ├── history/
│   ├── settings/
│   └── tab/
├── utils/
└── web/
```

**Recommendation**: Start with **flat modern structure** and refactor to feature modules later.

---

## 5. Step-by-Step Modernization Tasks

### Phase 0: Preparation (1–2 days)

1. **Backup** current project
2. Create new branch: `modernization/2026`
3. Update `.gitignore` (add `.idea/`, `build/`, etc.)

### Phase 1: Build System Upgrade

| Task | Details | Priority |
|------|---------|----------|
| Update `settings.gradle.kts` | Use version catalog + Kotlin DSL | High |
| Update root `build.gradle.kts` | AGP 8.5.2, Kotlin 2.0.20 | High |
| Update `app/build.gradle.kts` | Full dependency modernization | High |
| Add **Version Catalog** (`gradle/libs.versions.toml`) | Centralized dependency management | High |
| Fix CI workflow | Replace Maven with Gradle | High |
| Enable **Kotlin 2.0** compiler options | `languageVersion = "2.0"` | Medium |

### Phase 2: SDK & Compatibility

- `compileSdk = 35`
- `targetSdk = 35`
- `minSdk = 24`
- Update `AndroidManifest.xml` permissions
- Add `android:exported` attributes where needed

### Phase 3: Architecture Modernization

1. **Introduce Hilt** (Dependency Injection)
2. **Migrate to ViewModel + StateFlow**
3. Replace old presenters with ViewModels
4. Use **Navigation Component** for screen navigation
5. Convert Java classes to Kotlin gradually
6. Remove `kotlin-android-extensions` → use **ViewBinding** or **Compose**

### Phase 4: Dependency & Library Updates

**Core Updates**:
- Material → `com.google.android.material:material:1.12.0`
- Room → `2.6.1`
- Lifecycle → `2.8.4`
- Navigation → `2.7.7`
- Coroutines → `1.9.0`
- Hilt → `2.52`

**New Additions**:
- `androidx.datastore:datastore-preferences` (for settings)
- `androidx.webkit:webkit` (modern WebView features)
- `com.google.accompanist` (if using Compose)

### Phase 5: Code Quality & Tooling

- Add **Detekt** or **ktlint**
- Enable **Compose Compiler** (optional)
- Add **Room schema** location
- Set up **baseline profiles** (optional later)

---

## 6. Recommended Dependency Versions (2026)

```toml
# gradle/libs.versions.toml
[versions]
agp = "8.5.2"
kotlin = "2.0.20"
coreKtx = "1.13.1"
junit = "4.13.2"
androidxJunit = "1.2.1"
espressoCore = "3.6.1"
appcompat = "1.7.0"
material = "1.12.0"
constraintlayout = "1.0.1"
lifecycle = "2.8.4"
navigation = "2.7.7"
room = "2.6.1"
hilt = "2.52"
coroutines = "1.9.0"
datastore = "1.1.1"
webkit = "1.11.0"

[plugins]
android-application = { id = "com.android.application", version.ref = "agp" }
kotlin-android = { id = "org.jetbrains.kotlin.android", version.ref = "kotlin" }
hilt = { id = "com.google.dagger.hilt.android", version.ref = "hilt" }
ksp = { id = "com.google.devtools.ksp", version = "2.0.20-1.0.25" }

[libraries]
# ... (full list will be generated)
```

---

## 7. Migration Strategy

### Recommended Approach: Incremental

1. **Week 1**: Build system + SDK bump (keep everything working)
2. **Week 2**: Add Hilt + ViewBinding
3. **Week 3**: Introduce ViewModels for existing screens
4. **Week 4**: Migrate key classes to Kotlin
5. **Ongoing**: Refactor feature by feature

**Alternative**: Full rewrite in a new module (higher risk)

---

## 8. Risks & Mitigations

| Risk | Mitigation |
|------|------------|
| Breaking changes during upgrade | Work on a separate branch + frequent commits |
| WebView behavior changes | Thorough testing on physical devices |
| Dependency conflicts | Use Version Catalog + strict version alignment |
| Time consumption | Prioritize high-impact changes first |

---

## 9. Deliverables

After modernization, the project should have:

- ✅ Modern Gradle setup with Version Catalog
- ✅ Target SDK 35
- ✅ Kotlin 2.0
- ✅ Hilt DI
- ✅ ViewModel + StateFlow architecture
- ✅ Material 3 theming
- ✅ Clean, documented package structure
- ✅ Working CI pipeline

---

## 10. Next Actions

1. Approve this plan
2. I will generate:
   - Updated `gradle/libs.versions.toml`
   - New `build.gradle.kts` files
   - Modern project skeleton (optional)
   - Migration checklist

Would you like me to proceed with **generating the modernized build files** now?