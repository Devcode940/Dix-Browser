# Phase 2 Implementation Plan — Dix Browser

**Project**: Dix Browser (formerly EasyBrowser)  
**Date**: 2026-07-22  
**Focus**: Modern UX & Privacy

---

## Phase 2 Goals

1. **Incognito / Private Mode**
2. **Dark Mode & Theming**
3. **Ad Blocking** (basic)
4. **Gesture Navigation**
5. **Tab Enhancements**

---

## 1. Incognito Mode (Detailed Implementation)

### Files Created
- `IncognitoManager.kt`
- `IncognitoTabFragment.kt`
- `fragment_incognito.xml`

### Implementation Steps (Completed)
- ✅ Separate fragment with disabled storage
- ✅ No history/cookie saving
- ✅ Auto-clear on close
- ✅ Visual indicator

### Next Steps
- Add "New Incognito Tab" option in menu
- Modify `TabCacheManager` to support incognito tabs
- Add incognito flag to `TabInfo`

---

## 2. Dark Mode & Theming

### Files Created
- `ThemeManager.kt`

### Implementation Steps
- ✅ Theme switching logic
- Need to integrate with `BrowserActivity`
- Enable WebView dark mode using `WebSettingsCompat`

---

## 3. Download Listener (Completed)

**Wired up** in `PageNestedWebView.java`:
- `setDownloadListener` now calls `BrowserActivity.onDownloadStart()`

---

## 4. Phase 2 Roadmap

| Feature | Priority | Status | Files |
|---------|----------|--------|-------|
| Incognito Mode | High | ✅ Core Done | Incognito* |
| Dark Mode | High | ✅ Core Done | ThemeManager |
| Ad Blocking | Medium | ⬜ Planned | - |
| Gestures | Medium | ⬜ Planned | - |
| Tab Improvements | Low | ⬜ Planned | - |

---

## Recommended Next Actions

1. Add Incognito toggle in Settings
2. Implement Dark Mode in `BrowserActivity`
3. Create `IncognitoTabCacheManager`
4. Add basic ad blocking using `shouldInterceptRequest`

---

**Status**: Phase 2 foundation complete. Ready for full implementation.