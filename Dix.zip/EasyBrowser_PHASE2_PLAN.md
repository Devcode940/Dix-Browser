# Phase 2: Modern UX & Privacy

**Status**: Started  
**Features**: Incognito Mode + Dark Mode + Theming

---

## Phase 2 Features

### 1. Incognito / Private Mode
- Separate tab stack
- No history, cookies, or cache
- Clear data on exit

**Files Created**:
- `ui/incognito/IncognitoManager.kt`

### 2. Dark Mode & Theming
- System theme following
- Force Dark on WebView
- Material You support

**Files Created**:
- `ui/theme/ThemeManager.kt`

---

## Next Steps for Phase 2

- Add toggle in Settings
- Create Incognito tab handling in `TabCacheManager`
- Apply theme in `BrowserActivity`
- Enable WebView dark mode via `WebSettingsCompat`

---

**Dix Browser** — Phase 2 in progress.